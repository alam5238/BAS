#include "scenariohandler.h"

ScenarioHandler::ScenarioHandler()
{

}

