#ifndef RANDOMID_H
#define RANDOMID_H

#include <string>

std::string RandomId();

#endif // RANDOMID_H
