#ifndef PROCESSLOCATION_H
#define PROCESSLOCATION_H

#include <string>

std::string ProcessLocation(const std::string& RedirectUrl,const std::string& OriginalUrl);


#endif // PROCESSLOCATION_H
