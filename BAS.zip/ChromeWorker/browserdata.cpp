#include "browserdata.h"

BrowserData::BrowserData()
{

}

