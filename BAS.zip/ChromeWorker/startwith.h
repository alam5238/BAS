#ifndef STARTWITH_H
#define STARTWITH_H

#include <string>
using namespace std;


bool starts_with(const string& s1, const string& s2);


#endif // STARTWITH_H
