#ifndef EXTRACT_FUNCTIONS_H
#define EXTRACT_FUNCTIONS_H


#include <string>

std::string extract_functions(const std::string& code);

#endif // EXTRACT_FUNCTIONS_H
