#ifndef CHROMECOMMANDLINEPARSER_H
#define CHROMECOMMANDLINEPARSER_H

#include <vector>
#include <string>

std::vector<std::pair<std::string,std::string> > ParseChromeCommandLine();

#endif // CHROMECOMMANDLINEPARSER_H
