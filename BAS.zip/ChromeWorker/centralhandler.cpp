#include "centralhandler.h"

CentralHandler::CentralHandler()
{

}
