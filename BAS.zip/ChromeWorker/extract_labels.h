#ifndef EXTRACT_LABELS_H
#define EXTRACT_LABELS_H

#include <string>

std::string extract_labels(const std::string& code);

#endif // EXTRACT_LABELS_H
