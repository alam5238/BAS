#ifndef EXTRACT_RESOURCES_H
#define EXTRACT_RESOURCES_H


#include <string>

std::string extract_resources(const std::string& code);


#endif // EXTRACT_RESOURCES_H
