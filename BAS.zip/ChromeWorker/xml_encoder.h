#ifndef XML_ENCODER
#define XML_ENCODER

#include <string>
void xml_encode(std::string& data);
#endif // XML_ENCODER

