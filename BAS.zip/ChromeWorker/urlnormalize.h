#ifndef URLNORMALIZE_H
#define URLNORMALIZE_H

#include <string>
std::string urlnormalize(const std::string& url);

#endif // URLNORMALIZE_H
