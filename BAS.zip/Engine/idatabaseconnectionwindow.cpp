#include "idatabaseconnectionwindow.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IDatabaseConnectionWindow::IDatabaseConnectionWindow(QObject *parent) :
        QObject(parent)
    {
    }
}
