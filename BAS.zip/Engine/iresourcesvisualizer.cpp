#include "iresourcesvisualizer.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IResourcesVisualizer::IResourcesVisualizer(QObject *parent) :
        QObject(parent)
    {
    }
}
