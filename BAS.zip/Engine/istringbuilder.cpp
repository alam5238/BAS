#include "istringbuilder.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IStringBuilder::IStringBuilder(QObject *parent) :
        QObject(parent)
    {
    }
}
