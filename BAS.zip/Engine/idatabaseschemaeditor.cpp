#include "idatabaseschemaeditor.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IDatabaseSchemaEditor::IDatabaseSchemaEditor(QObject *parent) :
        QObject(parent)
    {
    }
}
