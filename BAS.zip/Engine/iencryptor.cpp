#include "iencryptor.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IEncryptor::IEncryptor(QObject *parent) :
        QObject(parent)
    {
    }
}
