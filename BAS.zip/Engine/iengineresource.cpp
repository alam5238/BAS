#include "iengineresource.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IEngineResource::IEngineResource(QObject *parent) :
        QObject(parent)
    {
    }
}
