#include "iprocesscomunicator.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IProcessComunicator::IProcessComunicator(QObject *parent) :
        QObject(parent)
    {
    }


}
