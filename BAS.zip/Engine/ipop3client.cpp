#include "ipop3client.h"
#include "every_cpp.h"

IPop3Client::IPop3Client(QObject *parent) :
    QObject(parent)
{
}
