#include "iconstructresource.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{

    IConstructResource::IConstructResource(QObject *parent) :
        QObject(parent)
    {
    }
}
