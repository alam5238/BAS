#include "isolver.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    ISolver::ISolver(QObject *parent) :
        QObject(parent)
    {
    }
}
