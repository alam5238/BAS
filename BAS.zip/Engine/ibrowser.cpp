#include "ibrowser.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IBrowser::IBrowser(QObject *parent) :
        QObject(parent)
    {
    }
}
