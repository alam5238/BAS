#include "iresources.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IResources::IResources(QObject *parent) :
        QObject(parent)
    {
    }
}
