#include "ipostpreparestrategyfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IPostPrepareStrategyFactory::IPostPrepareStrategyFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
