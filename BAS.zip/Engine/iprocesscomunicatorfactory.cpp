#include "iprocesscomunicatorfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IProcessComunicatorFactory::IProcessComunicatorFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
