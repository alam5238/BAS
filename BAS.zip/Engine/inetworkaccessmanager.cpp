#include "inetworkaccessmanager.h"
#include "every_cpp.h"



namespace BrowserAutomationStudioFramework
{
    INetworkAccessManager::INetworkAccessManager(QObject *parent) :
        QObject(parent)
    {
    }
}
