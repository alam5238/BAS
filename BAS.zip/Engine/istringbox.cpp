#include "istringbox.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IStringBox::IStringBox(QObject *parent) :
        QObject(parent)
    {
    }
}
