#include "iwaiterfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IWaiterFactory::IWaiterFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
