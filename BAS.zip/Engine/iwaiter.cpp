#include "iwaiter.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IWaiter::IWaiter(QObject *parent) :
        QObject(parent)
    {
    }
}
