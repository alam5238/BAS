#include "iresourcewidget.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IResourceWidget::IResourceWidget(QObject *parent) :
        QObject(parent)
    {
    }
}
