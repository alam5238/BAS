#include "ihtmlparserfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IHtmlParserFactory::IHtmlParserFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
