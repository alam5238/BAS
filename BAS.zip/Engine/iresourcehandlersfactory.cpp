#include "iresourcehandlersfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IResourceHandlersFactory::IResourceHandlersFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
