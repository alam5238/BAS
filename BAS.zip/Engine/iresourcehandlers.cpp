#include "iresourcehandlers.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IResourceHandlers::IResourceHandlers(QObject *parent) :
        QObject(parent)
    {
    }
}
