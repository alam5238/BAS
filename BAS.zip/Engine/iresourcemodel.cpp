#include "iresourcemodel.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IResourceModel::IResourceModel(QObject *parent) :
        QObject(parent)
    {
    }
}
