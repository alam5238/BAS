#include "irecordprocesscommunication.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IRecordProcessCommunication::IRecordProcessCommunication(QObject *parent) :
        QObject(parent)
    {
    }
}
