#include "iversioninfo.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IVersionInfo::IVersionInfo(QObject *parent) :
        QObject(parent)
    {
    }
}
