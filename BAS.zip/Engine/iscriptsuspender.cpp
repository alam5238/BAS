#include "iscriptsuspender.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IScriptSuspender::IScriptSuspender(QObject *parent) :
        QObject(parent)
    {
    }
}
