#include "iscriptresources.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IScriptResources::IScriptResources(QObject *parent) :
    QObject(parent)
    {
    }
}
