#include "iimapclient.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IImapClient::IImapClient(QObject *parent) :
        QObject(parent)
    {
    }
}
