#include "isystemtraynotifier.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    ISystemTrayNotifier::ISystemTrayNotifier(QObject *parent) :
        QObject(parent)
    {
    }
}
