#include "iresourcehandler.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IResourceHandler::IResourceHandler(QObject *parent) :
        QObject(parent)
    {
    }
}
