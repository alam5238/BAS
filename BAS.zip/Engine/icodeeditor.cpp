#include "icodeeditor.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    ICodeEditor::ICodeEditor(QObject *parent) :
        QObject(parent)
    {
    }
}
