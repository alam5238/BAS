#include "imultiworker.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IMultiWorker::IMultiWorker(QObject *parent) :
        QObject(parent)
    {
    }
}
