#include "imemoryinfo.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IMemoryInfo::IMemoryInfo(QObject *parent) :
        QObject(parent)
    {
    }
}
