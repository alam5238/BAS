#include "ihttpclientfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IHttpClientFactory::IHttpClientFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
