#include "itranslator.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    ITranslator::ITranslator(QObject *parent) :
        QObject(parent)
    {
    }
}
