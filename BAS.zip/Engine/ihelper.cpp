#include "ihelper.h"
#include "every_cpp.h"
namespace BrowserAutomationStudioFramework
{
    IHelper::IHelper(QObject *parent) :
        QObject(parent)
    {
    }
}
