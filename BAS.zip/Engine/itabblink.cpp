#include "itabblink.h"

#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    ITabBlink::ITabBlink(QObject *parent) :
        QObject(parent)
    {
    }
}
