#include "ireportdatavisualizer.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IReportDataVisualizer::IReportDataVisualizer(QObject *parent) :
        QObject(parent)
    {
    }
}
