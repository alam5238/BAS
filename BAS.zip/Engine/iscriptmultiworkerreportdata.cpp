#include "iscriptmultiworkerreportdata.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IScriptMultiWorkerReportData::IScriptMultiWorkerReportData(QObject *parent) :
    QObject(parent)
    {
    }
}
