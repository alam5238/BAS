#include "ilanguagemodel.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    ILanguageModel::ILanguageModel(QObject *parent) :
        QObject(parent)
    {
    }
}
