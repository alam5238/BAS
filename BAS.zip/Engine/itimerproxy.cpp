#include "itimerproxy.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    ITimerProxy::ITimerProxy(QObject *parent) :
        QObject(parent)
    {
    }
}
