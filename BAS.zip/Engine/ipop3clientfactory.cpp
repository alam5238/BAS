#include "ipop3clientfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{

    IPop3ClientFactory::IPop3ClientFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
