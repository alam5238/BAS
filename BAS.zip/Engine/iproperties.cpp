#include "iproperties.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IProperties::IProperties(QObject *parent) :
        QObject(parent)
    {
    }
}
