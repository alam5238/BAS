#include "iworker.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{

    IWorker::IWorker(QObject *parent) :
        QObject(parent)
    {
    }

}
