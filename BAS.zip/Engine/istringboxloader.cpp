#include "istringboxloader.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IStringBoxLoader::IStringBoxLoader(QObject *parent) :
        QObject(parent)
    {
    }
}
