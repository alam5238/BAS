#include "iworkersettings.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IWorkerSettings::IWorkerSettings(QObject *parent) :
        QObject(parent)
    {
    }
}
