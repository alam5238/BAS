#include "iresourcecontroller.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IResourceController::IResourceController(QObject *parent) :
        QObject(parent)
    {
    }
}
