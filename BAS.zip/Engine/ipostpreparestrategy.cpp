#include "ipostpreparestrategy.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IPostPrepareStrategy::IPostPrepareStrategy(QObject *parent) :
        QObject(parent)
    {
    }
}
