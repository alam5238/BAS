#include "idatabasestate.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IDatabaseState::IDatabaseState(QObject *parent) :
        QObject(parent)
    {
    }
}
