#include "iwebelement.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IWebElement::IWebElement(QObject *parent) :
        QObject(parent)
    {
    }
}
