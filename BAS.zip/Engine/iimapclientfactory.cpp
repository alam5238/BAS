#include "iimapclientfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IImapClientFactory::IImapClientFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
