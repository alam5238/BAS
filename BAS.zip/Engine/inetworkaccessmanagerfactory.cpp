#include "inetworkaccessmanagerfactory.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    INetworkAccessManagerFactory::INetworkAccessManagerFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
