#include "istringboxproxy.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IStringBoxProxy::IStringBoxProxy(QObject *parent) :
        QObject(parent)
    {
    }
}
