#include "isolverfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    ISolverFactory::ISolverFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
