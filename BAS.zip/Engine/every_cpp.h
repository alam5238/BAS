#ifndef EVERY_CPP_H
#define EVERY_CPP_H

#ifdef MEMORY_DEBUG
    #include "debug_new.h"
#endif

#endif // EVERY_CPP_H
