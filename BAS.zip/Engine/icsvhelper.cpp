#include "icsvhelper.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    ICsvHelper::ICsvHelper(QObject *parent) :
        QObject(parent)
    {
    }
}
