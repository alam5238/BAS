#include "ibrowserfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IBrowserFactory::IBrowserFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
