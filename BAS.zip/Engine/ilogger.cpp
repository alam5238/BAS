#include "ilogger.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{

    ILogger::ILogger(QObject *parent) :
        QObject(parent)
    {
    }
}
