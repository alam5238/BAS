#include "iengineresources.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IEngineResources::IEngineResources(QObject *parent) :
        QObject(parent)
    {
    }
}
