#include "idatabaseconnector.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IDatabaseConnector::IDatabaseConnector(QObject *parent) :
        QObject(parent)
    {
    }
}
