#include "iresourcewidgetfactory.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IResourceWidgetFactory::IResourceWidgetFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
