#include "iresourcewatcher.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IResourceWatcher::IResourceWatcher(QObject *parent) :
        QObject(parent)
    {
    }
}
