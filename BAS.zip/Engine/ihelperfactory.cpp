#include "ihelperfactory.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IHelperFactory::IHelperFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
