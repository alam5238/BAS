#include "idiffpatcher.h"

#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    IDiffPatcher::IDiffPatcher(QObject *parent) :
        QObject(parent)
    {

    }

}
