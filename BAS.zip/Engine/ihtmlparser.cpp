#include "ihtmlparser.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IHtmlParser::IHtmlParser(QObject *parent) :
        QObject(parent)
    {
    }
}
