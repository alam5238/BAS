#include "iskincontroller.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{
    ISkinController::ISkinController(QObject *parent) :
        QObject(parent)
    {
    }
}
