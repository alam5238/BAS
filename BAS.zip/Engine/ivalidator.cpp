#include "ivalidator.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{

    IValidator::IValidator(QObject *parent) :
        QObject(parent)
    {
    }
}
