#include "iworkerfactory.h"
#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IWorkerFactory::IWorkerFactory(QObject *parent) :
        QObject(parent)
    {
    }
}
