#include "ipreprocessor.h"
#include "every_cpp.h"

namespace BrowserAutomationStudioFramework
{

    IPreprocessor::IPreprocessor(QObject *parent) :
        QObject(parent)
    {
    }
}
