#include "istringcompress.h"

#include "every_cpp.h"


namespace BrowserAutomationStudioFramework
{
    IStringCompress::IStringCompress(QObject *parent) :
        QObject(parent)
    {
    }
}
